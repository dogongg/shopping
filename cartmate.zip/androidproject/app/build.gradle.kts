plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.example.cartmate"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.cartmate"
        minSdk = 23
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    buildFeatures {
        compose = false
    }
}

dependencies {
    // AndroidX 및 AppCompat
    implementation("androidx.appcompat:appcompat:1.6.1") // AppCompat 라이브러리 추가
    implementation("androidx.core:core-ktx:1.10.1") // Core KTX

    // Material Design
    implementation("com.google.android.material:material:1.11.0-alpha01")

    // Lifecycle
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.1")
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)

    // 테스트 라이브러리
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")

    implementation ("com.google.mlkit:barcode-scanning:16.1.1")
    implementation ("com.google.code.gson:gson:2.8.9")

}
