package com.example.cartmate

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class BarcodeScanActivity : AppCompatActivity() {
    private lateinit var itemRecyclerView: RecyclerView
    private lateinit var totalTextView: TextView
    private lateinit var calculateButton: Button
    private lateinit var homeButton: ImageButton

    private var itemList: MutableList<ProductItem> = mutableListOf()
    private lateinit var adapter: ProductItemAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_barcode_scan)

        // 뷰 초기화
        itemRecyclerView = findViewById(R.id.itemRecyclerView)
        totalTextView = findViewById(R.id.totalTextView)
        calculateButton = findViewById(R.id.calculateButton)
        homeButton = findViewById(R.id.buttonHome)

        // RecyclerView 설정
        adapter = ProductItemAdapter(itemList) { position -> removeItem(position) }
        itemRecyclerView.layoutManager = LinearLayoutManager(this)
        itemRecyclerView.adapter = adapter

        // 저장된 데이터 복원
        loadItems()

        // 계산 버튼 클릭 이벤트
        calculateButton.setOnClickListener {
            calculateTotalPrice()
        }

        // 홈 버튼 클릭 이벤트
        homeButton.setOnClickListener {
            saveItems() // 데이터 저장
            val intent = Intent(this, MenuActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    // 아이템 추가 함수
    fun addItem(product: ProductItem) {
        itemList.add(product)
        adapter.notifyDataSetChanged()
        calculateTotalPrice()
    }

    // 아이템 삭제 함수
    fun removeItem(position: Int) {
        itemList.removeAt(position)
        adapter.notifyDataSetChanged()
        calculateTotalPrice()
    }

    // 총액 계산 함수
    private fun calculateTotalPrice() {
        val total = itemList.sumOf { it.price * it.quantity }
        totalTextView.text = getString(R.string.total_price, total)
    }

    // 데이터 저장
    private fun saveItems() {
        val sharedPreferences = getSharedPreferences("BarcodeScanPrefs", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val json = Gson().toJson(itemList)
        editor.putString("itemList", json)
        editor.apply()
    }

    // 데이터 복원
    private fun loadItems() {
        val sharedPreferences = getSharedPreferences("BarcodeScanPrefs", Context.MODE_PRIVATE)
        val json = sharedPreferences.getString("itemList", null)
        if (!json.isNullOrEmpty()) {
            val type = object : TypeToken<MutableList<ProductItem>>() {}.type
            itemList.addAll(Gson().fromJson(json, type))
        }
    }
}
