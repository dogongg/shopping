import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.cartmate.ProductItem
import com.example.cartmate.R

class ItemListAdapter(
    private val items: MutableList<ProductItem>, // 상품 데이터 리스트
    private val onDelete: (Int) -> Unit   // 삭제 버튼 클릭 이벤트
) : RecyclerView.Adapter<ItemListAdapter.ItemViewHolder>() {

    // ViewHolder: 아이템 뷰와 데이터를 연결
    inner class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameTextView: TextView = itemView.findViewById(R.id.itemName)
        val quantityTextView: TextView = itemView.findViewById(R.id.itemQuantity)
        val priceTextView: TextView = itemView.findViewById(R.id.itemPrice)
        val deleteButton: Button = itemView.findViewById(R.id.deleteButton)
    }

    // 아이템 뷰 생성
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_row, parent, false) // item_row.xml 사용
        return ItemViewHolder(view)
    }

    // 데이터와 뷰 연결
    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = items[position]
        holder.nameTextView.text = item.name
        holder.quantityTextView.text = "수량: ${item.quantity}"
        holder.priceTextView.text = "₩${item.price * item.quantity}"
        holder.deleteButton.setOnClickListener {
            onDelete(position) // 삭제 버튼 클릭 이벤트 호출
        }
    }

    // 아이템 개수 반환
    override fun getItemCount(): Int = items.size
}
