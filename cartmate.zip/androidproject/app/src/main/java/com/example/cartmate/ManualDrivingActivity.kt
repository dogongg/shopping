package com.example.cartmate

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import android.view.animation.AnimationUtils

class ManualDrivingActivity : AppCompatActivity() {
    private var isManualMode = false // 초기 상태: 자동 모드

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manual_driving)

        // 레이아웃 요소 연결
        val buttonHome = findViewById<ImageView>(R.id.buttonHome)
        val buttonToggleMode = findViewById<Button>(R.id.buttonAutoMode)
        val stateIcon = findViewById<ImageView>(R.id.stateIcon)
        val statusText = findViewById<TextView>(R.id.statusText)

        // 초기 상태 설정
        updateUI(stateIcon, statusText, buttonToggleMode)

        // 홈 버튼 이벤트
        buttonHome.setOnClickListener {
            finish() // 이전 메뉴로 돌아가기
        }

        // 모드 전환 버튼 이벤트
        buttonToggleMode.setOnClickListener {
            toggleMode(stateIcon, statusText, buttonToggleMode)
        }
    }

    private fun toggleMode(stateIcon: ImageView, statusText: TextView, buttonToggleMode: Button) {
        // 애니메이션 로드
        val fadeOut = AnimationUtils.loadAnimation(this, R.anim.fade_out)
        val fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in)

        // 기존 상태 페이드 아웃
        stateIcon.startAnimation(fadeOut)
        statusText.startAnimation(fadeOut)

        // 상태 전환
        isManualMode = !isManualMode // 상태 변경: true ↔ false

        // 상태 전환 및 애니메이션 적용
        stateIcon.postDelayed({
            updateUI(stateIcon, statusText, buttonToggleMode)
            // 새로운 상태 페이드 인
            stateIcon.startAnimation(fadeIn)
            statusText.startAnimation(fadeIn)
        }, 500) // 500ms 지연
    }

    private fun updateUI(stateIcon: ImageView, statusText: TextView, buttonToggleMode: Button) {
        if (isManualMode) {
            stateIcon.setImageResource(R.drawable.ic_hand_mode)
            statusText.text = "현재 상태: 수동 모드"
            buttonToggleMode.text = "자동 모드로 전환"
        } else {
            stateIcon.setImageResource(R.drawable.ic_auto_mode)
            statusText.text = "현재 상태: 자동 모드"
            buttonToggleMode.text = "수동 모드로 전환"
        }
    }
}
