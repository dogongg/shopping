package com.example.cartmate

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class MenuActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        // 수동 운전 버튼 클릭 이벤트
        val manualControlButton = findViewById<LinearLayout>(R.id.manualControlButton)
        manualControlButton.setOnClickListener {
            // ManualDrivingActivity로 이동
            val intent = Intent(this, ManualDrivingActivity::class.java)
            startActivity(intent)
        }
        val purchaseButton = findViewById<LinearLayout>(R.id.purchaseButton)
        purchaseButton.setOnClickListener {
            val intent = Intent(this, BarcodeScanActivity::class.java)
            startActivity(intent)
        }
    }
}
