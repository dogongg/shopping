package com.example.cartmate

data class ProductItem(
    val id: String,
    val name: String,
    val quantity: Int,
    val price: Int
)
